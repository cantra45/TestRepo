export interface IDrivingLicence {
    firstName: string;
   lastName: string;
   dateofbirth: string;
    dlId:string;
}
