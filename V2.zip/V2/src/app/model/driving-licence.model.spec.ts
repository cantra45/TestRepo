import { DrivingLicence } from './driving-licence.model';

describe('DrivingLicence', () => {
  it('should create an instance', () => {
    expect(new DrivingLicence()).toBeTruthy();
  });
});
