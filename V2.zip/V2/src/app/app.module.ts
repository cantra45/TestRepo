import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainWizardComponent } from './components/main-wizard/main-wizard.component';
import { NgWizardModule, NgWizardConfig, THEME } from 'ng-wizard';
import { FileUploadComponent } from './components/file-upload/file-upload.component';

import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
 import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
 
const ngWizardConfig: NgWizardConfig = {
  theme: THEME.dots
};

@NgModule({
  declarations: [
    AppComponent,
    MainWizardComponent,
    FileUploadComponent
  ],
  imports: [    
    BrowserModule,
    AppRoutingModule,     
    NgWizardModule.forRoot(ngWizardConfig),
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    NgbModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
