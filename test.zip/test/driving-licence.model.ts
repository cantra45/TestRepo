export class DrivingLicence {
    firstName: string="";
   lastName: string="";
   dateofbirth: string="";
    dlId:string="";
    address:string="";
    gender:string="";
}
